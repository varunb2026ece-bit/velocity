import VelocityExperience from '@/components/velocity-experience'

export default function Page() {
  return <VelocityExperience />
}
