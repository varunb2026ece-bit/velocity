'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Menu, Volume2, VolumeX, X } from 'lucide-react'

type Car = {
  number: string
  name: string
  model: string
  year: string
  color: string
  image: string
  hp: string
  engine: string
  topSpeed: string
  acceleration: string
  detail: string
  modelNote: string
}

const cars: Car[] = [
  { number: '01', name: 'PORSCHE', model: '911 GT3 RS', year: '2023 · 992', color: '#d7282f', image: '/cars/porsche-911-gt3-rs.png', hp: '518', engine: '4.0L FLAT-SIX', topSpeed: '296 km/h', acceleration: '3.2 sec', detail: 'A study in downforce. Born for the circuit, engineered without compromise.', modelNote: 'A naturally aspirated flat-six wrapped in motorsport aerodynamics, with active DRS and a singular focus on the lap ahead.' },
  { number: '02', name: 'BMW', model: 'M4 CSL', year: '2023 · G82', color: '#83a9d8', image: '/cars/bmw-m4-csl.png', hp: '543', engine: '3.0L TWIN-TURBO I6', topSpeed: '307 km/h', acceleration: '3.7 sec', detail: 'Less weight. More feeling. A limited-edition expression of M performance.', modelNote: 'Lightweight construction meets a reworked twin-turbo straight-six, sharpened for the road and the circuit.' },
  { number: '03', name: 'AUDI', model: 'R8 V10 PERFORMANCE', year: '2022 · QUATTRO', color: '#c2c4c5', image: '/cars/audi-r8-v10.png', hp: '602', engine: '5.2L V10', topSpeed: '331 km/h', acceleration: '3.1 sec', detail: 'A naturally aspirated V10 at full song. A supercar with a singular voice.', modelNote: 'A mid-mounted 5.2-litre V10 and quattro all-wheel drive, delivering a visceral supercar experience.' },
  { number: '04', name: 'NISSAN', model: 'GT-R NISMO', year: '2024 · R35', color: '#9a9b9c', image: '/cars/nissan-gtr-nismo.png', hp: '600', engine: '3.8L TWIN-TURBO V6', topSpeed: '315 km/h', acceleration: '2.7 sec', detail: 'Precision, traction, and relentless pace. The legend, sharpened by NISMO.', modelNote: 'A hand-assembled twin-turbo V6, advanced all-wheel drive and purposeful carbon aero.'},
]

const navItems = [['HOME', '#home'], ['MODELS', '#collection'], ['TECHNOLOGY', '#performance'], ['ABOUT', '#about']]

function Navigation({ soundEnabled, onToggleSound }: { soundEnabled: boolean; onToggleSound: () => void }) {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('HOME')
  useEffect(() => {
    const update = () => {
      const current = navItems.find(([, href]) => {
        const section = document.querySelector(href)
        return section && section.getBoundingClientRect().top <= 150 && section.getBoundingClientRect().bottom > 150
      })
      if (current) setActive(current[0])
    }
    window.addEventListener('scroll', update, { passive: true })
    update()
    return () => window.removeEventListener('scroll', update)
  }, [])
  return <header className="site-header"><a className="brand" href="#home" aria-label="Velocity home"><span className="brand-mark">V</span><span>VELOCITY<span className="brand-sub">THE ART OF SPEED</span></span></a><nav className={open ? 'nav-links is-open' : 'nav-links'} aria-label="Main navigation">{navItems.map(([label, href]) => <a key={label} className={active === label ? 'active' : ''} href={href} onClick={() => setOpen(false)}>{label}</a>)}</nav><div className="nav-actions"><button className="sound-toggle" type="button" onClick={onToggleSound} aria-label={soundEnabled ? 'Mute video sound' : 'Play video sound'}>{soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}<span>{soundEnabled ? 'SOUND ON' : 'SOUND OFF'}</span></button><a className="nav-cta" href="mailto:hello@velocity.auto">CONTACT <ArrowUpRight size={14} /></a></div><button className="menu-toggle" type="button" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button></header>
}

function Hero({ soundEnabled }: { soundEnabled: boolean }) {
  return <section className="hero" id="home"><video className="hero-video" autoPlay muted={!soundEnabled} loop playsInline preload="auto" poster="/cars/porsche-911-gt3-rs.png" aria-label="Cinematic showcase of four performance cars"><source src="/videos/velocity-the-art-of-speed.mp4" type="video/mp4" /></video><div className="hero-shade" /><div className="hero-content"><p className="eyebrow"><span className="eyebrow-line" />01 / 04 &nbsp; SPORTS CAR COLLECTION</p><h1>VELOCITY<span className="hero-period">.</span></h1><p className="hero-subtitle">The art of performance.</p><p className="hero-copy">Four icons of engineering. One pursuit of the extraordinary. Meet the machines that move us.</p><div className="hero-actions"><a className="button button-light" href="#collection">EXPLORE MODELS <ArrowUpRight size={15} /></a><a className="button button-ghost" href="#performance">DISCOVER PERFORMANCE</a></div></div><div className="hero-meta"><span>01 — 04</span><span>ENGINEERED TO MOVE YOU</span><span>EST. IN MOTION</span></div><a className="scroll-cue" href="#collection" aria-label="Scroll to collection"><span>SCROLL TO EXPLORE</span><ArrowDown size={14} /></a></section>
}

function CarSlider() {
  const [current, setCurrent] = useState(0)
  const interacted = useRef(false)
  const move = (direction: number) => { interacted.current = true; setCurrent((index) => (index + direction + cars.length) % cars.length) }
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight') move(1)
      if (event.key === 'ArrowLeft') move(-1)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])
  const car = cars[current]
  return <section className="slider-section" aria-label="Featured car slider" style={{ '--car-accent': car.color } as React.CSSProperties}><div className="slider-top"><div><p className="eyebrow"><span className="eyebrow-line" />THE COLLECTION / 2025</p><h2>FOUR WAYS<br />TO FEEL <em>ALIVE.</em></h2></div><div className="slider-counter"><span>{car.number}</span><i />04</div></div><div className="slider-stage"><div className="slider-image-wrap"><img key={car.image} src={car.image} alt={`${car.name} ${car.model} performance car`} className="slider-image" /><span className="image-index">V / {car.number}</span></div><div className="slider-info"><p className="car-kicker">{car.number} / THE MACHINE</p><h3>{car.name}<br /><span>{car.model}</span></h3><p className="car-detail">{car.detail}</p><div className="spec-row"><div><span>POWER</span><strong>{car.hp}<small> HP</small></strong></div><div><span>0—100 KM/H</span><strong>{car.acceleration}</strong></div><div><span>TOP SPEED</span><strong>{car.topSpeed}</strong></div></div><div className="slider-bottom"><span className="engine-label">{car.engine}</span><a href="#collection" className="text-link">EXPLORE DETAILS <ArrowUpRight size={15} /></a></div></div></div><div className="slider-controls"><div className="slider-dots" role="tablist" aria-label="Choose a car">{cars.map((item, index) => <button key={item.number} type="button" role="tab" aria-label={`Show ${item.name} ${item.model}`} aria-selected={current === index} className={current === index ? 'dot active' : 'dot'} onClick={() => { interacted.current = true; setCurrent(index) }}><span>{item.number}</span></button>)}</div><div className="slider-arrows"><button type="button" onClick={() => move(-1)} aria-label="Previous car"><ArrowLeft size={17} /></button><button type="button" onClick={() => move(1)} aria-label="Next car"><ArrowRight size={17} /></button></div><span className="swipe-note">USE ← → TO EXPLORE</span></div></section>
}

function Collection() {
  return <section className="collection section-pad" id="collection"><div className="section-heading"><div><p className="eyebrow"><span className="eyebrow-line" />02 — THE LINE-UP</p><h2>THE <em>MODELS.</em></h2></div><p className="section-intro">Four icons. Four distinct philosophies.<br />One shared pursuit: the extraordinary.</p></div><div className="model-list">{cars.map((car) => <article className="model-row" key={car.number}><a className="model-image" href="#performance" aria-label={`Explore ${car.name} ${car.model}`}><img src={car.image} alt={`${car.name} ${car.model}`} loading="lazy" /><span>{car.number} / 04</span></a><div className="model-copy"><p className="model-year">{car.year}</p><p className="model-make">{car.name}</p><h3>{car.model}</h3><p className="model-description">{car.modelNote}</p><dl className="model-specs"><div><dt>ENGINE</dt><dd>{car.engine}</dd></div><div><dt>POWER</dt><dd>{car.hp} HP</dd></div><div><dt>TOP SPEED</dt><dd>{car.topSpeed}</dd></div><div><dt>0–100 KM/H</dt><dd>{car.acceleration}</dd></div></dl><a className="model-link" href="#performance">VIEW PERFORMANCE <ArrowUpRight size={15} /></a></div></article>)}</div><p className="spec-disclaimer">Specifications are reference values; exact figures vary by model year and market.</p></section>
}

function Performance() {
  const technologies = [
    { number: '01', title: 'AERODYNAMICS', description: 'Active wings, venturi floors and carbon diffusers press each car into the tarmac at speed.' },
    { number: '02', title: 'POWERTRAINS', description: 'From a naturally aspirated flat-six to a hand-assembled twin-turbo V6 — four distinct answers to the same question.' },
    { number: '03', title: 'LIGHTWEIGHTING', description: 'Carbon panels, purposeful materials and obsessive detail trim mass where it matters most.' },
  ]
  return <section className="performance section-pad" id="performance"><div className="performance-heading"><p className="eyebrow"><span className="eyebrow-line" />03 — ENGINEERING</p><h2>THE <em>TECHNOLOGY.</em></h2><p>Every detail has a reason. Every innovation, a feeling.</p></div><div className="technology-grid">{technologies.map((item) => <article className="technology-card" key={item.number}><span>{item.number}</span><div className="technology-rule" /><h3>{item.title}</h3><p>{item.description}</p></article>)}</div></section>
}

function About() {
  return <section className="about section-pad" id="about"><div className="about-visual"><img src="/cars/audi-r8-v10.png" alt="Silver Audi R8 emerging from a shadowy tunnel" loading="lazy" /><span className="about-stamp">PASSION<br />IN EVERY<br />DETAIL</span><span className="about-caption">DESIGNED TO BE FELT. / 001</span></div><div className="about-copy"><p className="eyebrow"><span className="eyebrow-line" />04 — THE STUDIO</p><h2>BEYOND<br />THE <em>MACHINE.</em></h2><p>VELOCITY celebrates the engineering, design and emotion behind the world&apos;s most extraordinary performance cars.</p><p>Because performance is more than a number. It is the instant the road opens up, the engine comes alive, and everything else disappears.</p><a className="text-link" href="#collection">FIND YOUR VELOCITY <ArrowUpRight size={15} /></a></div></section>
}

function Footer() {
  return <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">V</span><span>VELOCITY<span className="brand-sub">THE ART OF SPEED</span></span></a><p>MADE FOR THE MOMENT<br />BEFORE THE HORIZON.</p><nav aria-label="Footer navigation">{navItems.map(([label, href]) => <a key={label} href={href}>{label}</a>)}<a href="mailto:hello@velocity.auto">CONTACT</a></nav><div className="footer-bottom"><span>© 2025 VELOCITY. ALL RIGHTS RESERVED.</span><a href="#home">BACK TO TOP ↑</a><span>THE ART OF SPEED.</span></div></footer>
}

export default function VelocityExperience() {
  const [soundEnabled, setSoundEnabled] = useState(false)
  return <><Navigation soundEnabled={soundEnabled} onToggleSound={() => setSoundEnabled((enabled) => !enabled)} /><main><Hero soundEnabled={soundEnabled} /><CarSlider /><Collection /><Performance /><About /></main><Footer /></>
}
